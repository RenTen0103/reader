const express = require('express')
import { Express } from 'express-serve-static-core';
let app: Express;
let server;
export const startServer = (p: string) => {
    app = express()
    if (server != null) {
        server.close()
    }

    app.use(express.static(p))
    server = app.listen(12356)
}