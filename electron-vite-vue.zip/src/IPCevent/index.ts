import { ipcRenderer } from 'electron';
import { voidloadEpub } from '../epub';
import { nav } from '../epub/nav';
import { bookdataStore } from '../pinia';

export const ipcEventInit = () => {
    ipcRenderer.on('opfData', (_, data, fiePath) => {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(data, "text/xml");
        console.log(fiePath);

        tocAns(xmlDoc, fiePath)
    })

    ipcRenderer.on('navData', (_, data) => {
        let toc = nav(data)
        const store = bookdataStore()
        store.nav = toc
    })

    ipcRenderer.on('dirmap', (_, data) => {
        const store = bookdataStore()
        store.dirmap.push(data)
    })
}


const tocAns = (xmlDoc: Document, fielPath: string) => {
    let tocRef;
    let cover;
    let type;

    const items = xmlDoc.getElementsByTagName('dc:rights')
    if (items[0].innerHTML == 'voidlord') {
        type = 'voidload'
    }


    switch (type) {
        case 'voidload':
            voidloadEpub(xmlDoc, fielPath)
            break;

        default:
            break;
    }
}